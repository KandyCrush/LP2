﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btMensalista = new System.Windows.Forms.Button();
            this.btHorista = new System.Windows.Forms.Button();
            this.btnTesteMbox = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btMensalista
            // 
            this.btMensalista.Location = new System.Drawing.Point(143, 93);
            this.btMensalista.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btMensalista.Name = "btMensalista";
            this.btMensalista.Size = new System.Drawing.Size(162, 48);
            this.btMensalista.TabIndex = 0;
            this.btMensalista.Text = "Mensalista";
            this.btMensalista.UseVisualStyleBackColor = true;
            this.btMensalista.Click += new System.EventHandler(this.button1_Click);
            // 
            // btHorista
            // 
            this.btHorista.Location = new System.Drawing.Point(344, 93);
            this.btHorista.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btHorista.Name = "btHorista";
            this.btHorista.Size = new System.Drawing.Size(162, 48);
            this.btHorista.TabIndex = 1;
            this.btHorista.Text = "Horista";
            this.btHorista.UseVisualStyleBackColor = true;
            this.btHorista.Click += new System.EventHandler(this.btHorista_Click);
            // 
            // btnTesteMbox
            // 
            this.btnTesteMbox.Location = new System.Drawing.Point(227, 196);
            this.btnTesteMbox.Margin = new System.Windows.Forms.Padding(6);
            this.btnTesteMbox.Name = "btnTesteMbox";
            this.btnTesteMbox.Size = new System.Drawing.Size(207, 96);
            this.btnTesteMbox.TabIndex = 2;
            this.btnTesteMbox.Text = "Teste MessageBox";
            this.btnTesteMbox.UseVisualStyleBackColor = true;
            this.btnTesteMbox.Click += new System.EventHandler(this.btnTesteMbox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.btnTesteMbox);
            this.Controls.Add(this.btHorista);
            this.Controls.Add(this.btMensalista);
            this.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btMensalista;
        private System.Windows.Forms.Button btHorista;
        private System.Windows.Forms.Button btnTesteMbox;
    }
}

