﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double peso, altura, IMC;

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (altura == 0)
            {
                MessageBox.Show("Não é possível dividir por zero!");
                mskbxAltura.Focus();
                return;
            }
            else
                IMC = peso / Math.Pow(altura,2);
                IMC = Math.Round(IMC,1);
                txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }
            else if(IMC <= 24.9)
            {
                MessageBox.Show("NORMAL");
            }
            else if(IMC <= 29.9)
            {
                MessageBox.Show("SOBREPESO");
            }
            else if(IMC <= 39.9)
            {
                MessageBox.Show("OBESIDADE");
            }
            else
                MessageBox.Show("OBESIDADE GRAVE");
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}
