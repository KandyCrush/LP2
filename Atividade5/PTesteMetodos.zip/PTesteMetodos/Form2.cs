﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio2 : Form
    {
        string plv1, plv2, incluido;
        public frmexercicio2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void frmexercicio2_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            plv1 = textBox1.Text;
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            plv2 = textBox2.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int contlet = plv2.Length;
            string concat = plv2.Insert(contlet / 2, textBox1.Text);
            MessageBox.Show($"A palavra final ficou da seguinte forma: {concat}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contlet = plv1.Length;
            string palavrafin = plv1.Insert(contlet /2, "**");
            MessageBox.Show($"A palavra final ficou da seguinte forma: {palavrafin}");


        }

        private void btncomparar_Click(object sender, EventArgs e)
        {
            if (string.Compare(plv1, plv2) == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
            }
        }
    }
}
