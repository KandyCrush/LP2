﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int numero1, numero2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNumero1.Text,out numero1))
            {
                MessageBox.Show("O número informado não é válido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out numero1))
            {
                MessageBox.Show("O número informado não é válido!");
                txtNumero1.Focus();
            }
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if ((!int.TryParse(txtNumero1.Text, out numero1)) || (!int.TryParse(txtNumero2.Text, out numero2)) || (numero2 <= numero1))
            {
                MessageBox.Show("Os números são inválidos!");
                txtNumero1.Focus();
            }
            else
            {
                Random objR = new Random();
                int aleatorio = objR.Next(numero1, numero2);
                MessageBox.Show(aleatorio.ToString());
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
        }
    }
}
