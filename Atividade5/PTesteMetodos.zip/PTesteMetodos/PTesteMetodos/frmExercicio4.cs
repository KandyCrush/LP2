﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contaNum=0, contador=0;
            while (contador<rchtxtTexto.Text.Length)
            {
                if (char.IsNumber(rchtxtTexto.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show("Quantidade de números: "+contaNum);
        }

        private void btnEspBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i=0; i<rchtxtTexto.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtTexto.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            MessageBox.Show("Posição do 1° caractere em braco: "+posicao);
        }

        private void btnContLetras_Click(object sender, EventArgs e)
        {
            int contaLetras=0;
            foreach (var c in rchtxtTexto.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetras++;
                }
            }
            MessageBox.Show("Quantidade de letras: "+contaLetras);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchtxtTexto.Clear();
        }
    }
}
