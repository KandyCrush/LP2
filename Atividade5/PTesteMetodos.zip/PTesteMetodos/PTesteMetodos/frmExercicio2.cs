﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        string palavra1, palavra2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtPalavra1_Validated(object sender, EventArgs e)
        {
            palavra1 = txtPalavra1.Text;
        }

        private void txtPalavra2_Validated(object sender, EventArgs e)
        {
            palavra2 = txtPalavra2.Text;
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int contLetraPalavra2 = palavra2.Length;
            string concatena = palavra2.Insert(contLetraPalavra2 / 2, txtPalavra1.Text);
            MessageBox.Show($"A palavra final fica: {concatena}");
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int contLetraPalavra1 = palavra1.Length;
            string palavraFinal = palavra1.Insert(contLetraPalavra1 / 2, "**");
            MessageBox.Show($"A palavra final fica: {palavraFinal}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtPalavra2.Clear();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            if (string.Compare(palavra1, palavra2) == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
                txtPalavra2.Focus();
            }
        }
    }
}
