﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio3 : Form
    {
        public frmexercicio3()
        {
            InitializeComponent();
        }

        private void btnarrancarletra_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox2.Text.Replace(textBox1.Text, "");
        }

        private void inverter_Click(object sender, EventArgs e)
        {
            char[] vetor = textBox1.Text.ToCharArray();
            Array.Reverse(vetor);
            textBox2.Text = "";
            foreach (char c in vetor)
            {
                textBox2.Text += c;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
