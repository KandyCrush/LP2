﻿namespace Ploops
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.frmExercicio1 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio2 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio3 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExercicio4 = new System.Windows.Forms.ToolStripMenuItem();
            this.Sair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmExercicio1,
            this.frmExercicio2,
            this.frmExercicio3,
            this.frmExercicio4,
            this.Sair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // frmExercicio1
            // 
            this.frmExercicio1.Name = "frmExercicio1";
            this.frmExercicio1.Size = new System.Drawing.Size(71, 20);
            this.frmExercicio1.Text = "Exercício1";
            this.frmExercicio1.Click += new System.EventHandler(this.frmExercicio1_Click);
            // 
            // frmExercicio2
            // 
            this.frmExercicio2.Name = "frmExercicio2";
            this.frmExercicio2.Size = new System.Drawing.Size(71, 20);
            this.frmExercicio2.Text = "Exercício2";
            this.frmExercicio2.Click += new System.EventHandler(this.frmExercicio2_Click);
            // 
            // frmExercicio3
            // 
            this.frmExercicio3.Name = "frmExercicio3";
            this.frmExercicio3.Size = new System.Drawing.Size(71, 20);
            this.frmExercicio3.Text = "Exercício3";
            this.frmExercicio3.Click += new System.EventHandler(this.frmExercicio3_Click);
            // 
            // frmExercicio4
            // 
            this.frmExercicio4.Name = "frmExercicio4";
            this.frmExercicio4.Size = new System.Drawing.Size(71, 20);
            this.frmExercicio4.Text = "Exercício4";
            this.frmExercicio4.Click += new System.EventHandler(this.frmExercicio4_Click);
            // 
            // Sair
            // 
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(38, 20);
            this.Sair.Text = "Sair";
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio1;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio2;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio3;
        private System.Windows.Forms.ToolStripMenuItem frmExercicio4;
        private System.Windows.Forms.ToolStripMenuItem Sair;
    }
}

