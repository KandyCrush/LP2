﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int contNum = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(c))
                    contNum++;
            }
            MessageBox.Show("A quantidade de espaços em bracos são: "+contNum);
        }

        private void btnQtdR_Click(object sender, EventArgs e)
        {
            int i = 0, contR=0;
            while (i < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[i] == 'R')
                    contR++;
                i++;
            }
            MessageBox.Show("A quantidade de vezes que apareceu o dígito R foi: "+contR);
        }

        private void btnQtdLetrasPares_Click(object sender, EventArgs e)
        {
            int contPares = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length - 1; i++)
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i+1])
                    contPares++;
            }
            MessageBox.Show("A quantidade de pares de letras são: "+contPares);
        }
    }
}
