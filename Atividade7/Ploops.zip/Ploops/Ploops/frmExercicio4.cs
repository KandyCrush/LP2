﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        int numero;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            double salarioBruto=0;
            int B=0, C=0, D=0;

            if (Convert.ToDouble(txtProducao.Text) >= 100)
                B = 1;
            if (Convert.ToDouble(txtProducao.Text) >= 120)
                C = 1;
            if (Convert.ToDouble(txtProducao.Text) >= 150)
                D = 1;

            salarioBruto = Convert.ToDouble(txtSalario.Text) + 
                Convert.ToDouble(txtSalario.Text) * (0.05*B + 0.1*C + 0.1*D) +
                Convert.ToDouble(txtGratificacao.Text);

            if (salarioBruto > 7000)
            {
                if ((Convert.ToDouble(txtProducao.Text) >= 150)
                    && (Convert.ToDouble(txtGratificacao.Text) > 0))
                    MessageBox.Show("O salário bruto do " + txtNome.Text + " é: R$" + salarioBruto.ToString("N2"));
                else
                {
                    salarioBruto = 7000;
                    MessageBox.Show("O salário bruto do " + txtNome.Text + " é: R$" + salarioBruto.ToString("N2"));
                }
            }
            else
                MessageBox.Show("O salário bruto do " + txtNome.Text + " é: R$" + salarioBruto.ToString("N2"));
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out numero) || (numero < 0))
            {
                MessageBox.Show("A quantidade produzida não é válida!");
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtSalario.Text, out numero) || (numero < 0))
            {
                MessageBox.Show("O salário informado não é válido!");
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtGratificacao.Text, out numero) || (numero < 0))
            {
                MessageBox.Show("A quantidade de gratificação não é válido!");
                txtGratificacao.Focus();
            }
        }
    }
}
