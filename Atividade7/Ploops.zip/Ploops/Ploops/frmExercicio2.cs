﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio2 : Form
    {
        int numero;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtboxNumero_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out numero) || (numero < 1))
            {
                MessageBox.Show("O número informado não é válido!");
                txtNumero.Focus();
            }
        }

        private void btnNumH_Click(object sender, EventArgs e)
        {
            double H=0;
            for (int i = 1; i <= numero; i++)
            {
                H += 1 / (double)i;
            }
            MessageBox.Show($"O valor de H é: {H.ToString("N2")}");
        }
    }
}
