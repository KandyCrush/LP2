﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            char[] vetorString;
            string palavraMinusculo;
            palavraMinusculo = txtPalavra.Text.ToLower().Replace(" ", "");
            vetorString = palavraMinusculo.ToCharArray();
            Array.Reverse(vetorString);
            string palavraInvertida = new string(vetorString);
            if (palavraInvertida.Equals(palavraMinusculo))
                MessageBox.Show("A palavra " + txtPalavra.Text + " é um palíndromo!");
            else
                MessageBox.Show("A palavra " + txtPalavra.Text + " não é um palíndromo!");
            MessageBox.Show("A palavra é: " + palavraMinusculo);
        }
    }
}
