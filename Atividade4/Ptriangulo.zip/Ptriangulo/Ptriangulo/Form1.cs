﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double valorA, valorB, valorC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtValorA.Text, out valorA)) || valorA == 0)
            {
                MessageBox.Show("Número inválido");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if((!Double.TryParse(txtValorB.Text, out valorB)) || valorB == 0)
            {
                MessageBox.Show("Número inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if((!Double.TryParse(txtValorC.Text, out valorC)) || valorC == 0)
            {
                MessageBox.Show("Número inválido");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!((Math.Abs(valorB - valorC) < valorA) && valorA < (valorB + valorC)))
            {
                MessageBox.Show("Os lados não pertencem a um triângulo!");
            }
            else if (!((Math.Abs(valorA - valorC) < valorB) && valorB < (valorA + valorC)))
            {
                MessageBox.Show("Os lados não pertencem a um triângulo!");
            }
            else if (!((Math.Abs(valorA - valorB) < valorC) && valorC < (valorA + valorB)))
            {
                MessageBox.Show("Os lados não pertencem a um triângulo!");
            }
            else
            {
                if ((valorA == valorB) && (valorA == valorC))
                {
                    MessageBox.Show("É um triângulo equilátero");
                }
                else if ((valorA == valorB) && (valorA != valorC))
                {
                    MessageBox.Show("É um triângulo isósceles");
                }
                else
                    MessageBox.Show("É um triângulo escaleno");
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear(); 
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
