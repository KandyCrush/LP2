﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");
            
                if(auxiliar == "")
                {
                    break;
                }

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);

            auxiliar = "";

            /* primeira opção
            foreach(int x in vetor)
            {
                auxiliar += x+"\n";
            }
            */
            
            auxiliar = string.Join("\n", vetor);

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "", saida = "";
            double media = 0;

            //for(int i = 0; i < 20; i++)
            for(int i = 0; i < 2; i++)
            {
                media = 0;
                for (int j = 0;j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j+1}ª nota do aluno {i+1}", 
                        "Entrada de dados");
                    
                    if(!double.TryParse(auxiliar,out notas[i,j]) || notas[i, j]<0
                        || notas[i, j]>10)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                media /= 3;
                saida += $"Aluno {i+1}: média: {media.ToString("N2")}\n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercício4 obj4 = new frmExercício4();
            obj4.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string[] nomes = { "Ana", "André", "Beatriz", "Camila João", "Joana", "Otávio",
            "Marcelo", "Pedro", "Thais"};

            foreach(string str in nomes)
            {
                if(str != "Otávio")
                    MessageBox.Show(str);
            }            
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj5 = new frmExercicio5();
            obj5.Show();
        }
    }
}
