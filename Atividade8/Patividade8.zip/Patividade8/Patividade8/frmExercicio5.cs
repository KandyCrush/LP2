﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int numRA = 3, cont = 0 , numQuestoes = 2;
            char[] gabarito = {'A', 'E', 'C', 'D', 'B', 'C', 'E', 'B', 'A', 'A'};
            string auxiliar = "";
            string[] vetor1 = new string[30];

            lstbxResultado.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < numQuestoes; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite resposta da alternativa {j + 1}", "Entrada de Dados");

                    if (auxiliar.Replace(" ", "").Length == 0)
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                        vetor1[cont] = auxiliar.ToUpper();
                    cont++;
                }
            }
            cont = 0;
            for (int i = 0;i < numRA; i++)
            {
                for (int j = 0; j < numQuestoes; j++)
                {
                    if (vetor1[cont] == Convert.ToString(gabarito[cont]))
                        lstbxResultado.Items.Add($"O aluno:{i+1} acertou, a questão:" +
                            $" {j+1} era {gabarito[cont]} escolheu {vetor1[cont]}");
                    else
                        lstbxResultado.Items.Add($"O aluno:{i + 1} errou, a questão:" +
                            $" {j + 1} era {gabarito[cont]} escolheu {vetor1[cont]}");
                    cont++;
                }
            }
        }
    }
}
