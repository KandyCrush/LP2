﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        int numero = 0;
        string auxiliar = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            //numCurso e numAno são a linha e a coluna da matriz respectivamente
            int numCurso = 3, numAno = 5;
            int totalCurso = 0, totalGeral = 0;

            //Criando a matriz conforme as dimensões informadas em numCurso e numAno
            int[,] vestibular = new int[numCurso, numAno];

            //Começando o loop da matriz
            for (int i = 0; i < numCurso; i++)
            {
                totalCurso = 0;
                for (int j = 0; j < numAno; j++)
                {
                    //Recebendo o total de alunos por cada no pelo Inputbox
                    auxiliar = Interaction.InputBox($"Digite o total de alunos no ano {j + 1}!",
                        "Entrada de Dados");

                    /*Validando a entrada de dados sendo um número inteiro positivo
                     e adicionando no listBox os valores de cada curso e somando no total do curso*/
                    if (!int.TryParse(auxiliar, out numero) || (numero < 0))
                    {
                        MessageBox.Show("O número não é válido!");
                        j--;
                    }
                    else
                    {
                        lstbxResultado.Items.Add($"Total do curso {i + 1} do Ano {j + 1}: {auxiliar}");
                        totalCurso += Convert.ToInt32(auxiliar);
                    }
                    
                }
                lstbxResultado.Items.Add("_______________________________");
                lstbxResultado.Items.Add($"Total curso { i + 1}: { totalCurso}");
                totalGeral += totalCurso;
            }
            lstbxResultado.Items.Add("_______________________________");
            lstbxResultado.Items.Add($"Total Geral {totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
