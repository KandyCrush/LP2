﻿namespace Pvestibular01
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReceberDados = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lstbxResultado = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnReceberDados
            // 
            this.btnReceberDados.Location = new System.Drawing.Point(33, 30);
            this.btnReceberDados.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnReceberDados.Name = "btnReceberDados";
            this.btnReceberDados.Size = new System.Drawing.Size(169, 107);
            this.btnReceberDados.TabIndex = 0;
            this.btnReceberDados.Text = "Receber Dados";
            this.btnReceberDados.UseVisualStyleBackColor = true;
            this.btnReceberDados.Click += new System.EventHandler(this.btnReceberDados_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(33, 160);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(169, 107);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lstbxResultado
            // 
            this.lstbxResultado.FormattingEnabled = true;
            this.lstbxResultado.ItemHeight = 33;
            this.lstbxResultado.Location = new System.Drawing.Point(229, 30);
            this.lstbxResultado.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lstbxResultado.Name = "lstbxResultado";
            this.lstbxResultado.Size = new System.Drawing.Size(720, 598);
            this.lstbxResultado.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1471, 825);
            this.Controls.Add(this.lstbxResultado);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnReceberDados);
            this.Font = new System.Drawing.Font("Arial Narrow", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReceberDados;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.ListBox lstbxResultado;
    }
}

